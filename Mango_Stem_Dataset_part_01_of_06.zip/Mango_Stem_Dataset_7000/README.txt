MANGO STEM DATASET - 7,000 IMAGE PREPARATION

Counts: train 5,600; validation 700; test 700; total 7,000. All images are 224x224 JPEG.

LABEL SAFETY: The supplied PDF contains 67 images but no reliable per-image disease labels. Images include full tree/stem views, bark close-ups, screenshots/reference material and some non-stem content. Therefore all generated images are provisionally labelled Unverified_Mango_Stem. None has been declared Healthy, Gummosis, Canker or Dieback without confirmation.

Augmentation: The 67 source images were split by source first (54 train, 7 validation, 6 test), then variants were generated only within their assigned split. Variants use flips, right-angle rotations, brightness, contrast and color changes, then resize to 224x224. These are derived variants, NOT 7,000 independent field observations.

IMPORTANT FOR RESEARCH: This is a one-class provisional image collection, not a validated four-class disease dataset. Review class_labeling_template.csv and assign expert-confirmed labels. Add genuine disease images for underrepresented classes. For final unbiased evaluation, use original unaugmented images in validation/test and keep all images from the same tree/session in one split.
